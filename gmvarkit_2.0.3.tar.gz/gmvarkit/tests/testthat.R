library(testthat)
library(gmvarkit)

test_check("gmvarkit")
